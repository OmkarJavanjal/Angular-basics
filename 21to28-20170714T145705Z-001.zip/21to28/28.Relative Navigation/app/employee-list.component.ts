import { Component } from '@angular/core';

@Component({
    selector: 'employee-list',
    template: '<h3>Employee List</h3>'

})
export class EmployeeListComponent{}