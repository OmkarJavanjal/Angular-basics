import { Component } from '@angular/core';

@Component({
template:'<h3>Welcome to Angular Routing</h3>'
})
export class HomeComponent{}