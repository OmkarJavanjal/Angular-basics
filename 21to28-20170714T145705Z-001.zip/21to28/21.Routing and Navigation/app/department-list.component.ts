import { Component } from '@angular/core';

@Component({
    selector: 'department-list',
    template: '<h3>Department List</h3>'

})
export class DepartmentListComponent{}