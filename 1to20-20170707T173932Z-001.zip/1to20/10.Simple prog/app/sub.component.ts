import { Component } from '@angular/core';
@Component({
  selector: 'sub-app',
  template: '<h1>Sub App</h1>'
})
export class SubComponent { }
